### README
Paul Bivrell - CS410 FA2018 - PA1

To compile:
`make`

_Compiles src/ into bin/ directory_

To run:

Requirements:
* .obj files must be in the same directory as where you run the java command

`./runner.sh driver_file`
_This executes a bash script which runs the java program below_

OR
```
java -cp "/lib/Jama-1.0.3.jar:bin" Modeltoworld driver_file
```
__Note the results will appear in the running directory under a directory driverXX as specified in the assignment__

