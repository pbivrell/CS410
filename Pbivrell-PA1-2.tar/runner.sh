#!/bin/bash
java -cp "lib/Jama-1.0.3.jar:bin/" Modeltoworld $1
