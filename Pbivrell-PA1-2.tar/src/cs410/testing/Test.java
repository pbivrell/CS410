package cs410.testing;

//import org.jblas.DoubleMatrix;

public class Test{
    public static void main(String[] args){
        //System.out.println(DoubleMatrix.zeros(4));
        //System.out.println(DoubleMatrix.zeros(3).transpose());
    }
}

